# Hebbian/Anti-Hebbian Learning for Pytorch

